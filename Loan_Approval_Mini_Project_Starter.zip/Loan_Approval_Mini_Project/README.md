# Loan Approval Prediction Mini Project

This is a clean starter structure for building the project in VS Code. The project is intentionally split into small stages to reduce mistakes.

## Before running
1. Install Python and VS Code.
2. Extract this ZIP.
3. Open the `Loan_Approval_Mini_Project` folder in VS Code.
4. Download the Kaggle Loan Prediction dataset and place its training CSV at `dataset/train.csv`.
5. Open the VS Code terminal in the project root.

## Create and activate a virtual environment (Windows CMD)
```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If you use PowerShell, activation is:
```powershell
.\.venv\Scripts\Activate.ps1
```

## Planned workflow
Run these scripts from the project root, in order:
```bat
python data_mining\01_inspect_data.py
python data_mining\02_preprocessing.py
python data_mining\03_eda.py
python data_mining\04_train_model.py
```

The later scripts will be completed after we verify the dataset's actual columns and target values. Do not run unfinished stages yet.

## Dataset
Use the Kaggle Loan Prediction dataset linked in the conversation. Put the training file at:
`dataset/train.csv`

Do not upload private or sensitive real applicant data. Use the public educational dataset for this project.

## Current status
- Folder structure created.
- Starter inspection script included.
- Preprocessing, EDA, training, and Django components are placeholders until the dataset is checked.
