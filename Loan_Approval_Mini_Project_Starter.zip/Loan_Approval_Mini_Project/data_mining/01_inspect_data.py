from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_ROOT / "dataset" / "train.csv"

def main():
    if not DATA_PATH.exists():
        print(f"Dataset not found: {DATA_PATH}")
        print("Download the Kaggle training CSV and save it as dataset/train.csv.")
        return

    df = pd.read_csv(DATA_PATH)
    print("\n--- Dataset shape ---")
    print(df.shape)
    print("\n--- First 10 rows ---")
    print(df.head(10).to_string())
    print("\n--- Column names ---")
    print(df.columns.tolist())
    print("\n--- Data types and non-null counts ---")
    df.info()
    print("\n--- Missing values by column ---")
    print(df.isnull().sum().sort_values(ascending=False).to_string())
    print("\n--- Duplicate rows ---")
    print(int(df.duplicated().sum()))
    print("\n--- Summary statistics ---")
    print(df.describe(include="all").transpose().to_string())

if __name__ == "__main__":
    main()
