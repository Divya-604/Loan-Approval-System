"""
Stage 4 placeholder.
We will create a reproducible train/test pipeline, train a classification model,
evaluate it with suitable metrics, and save the fitted pipeline in artifacts/.
"""
def main():
    print("Model training stage is not configured yet. Complete preprocessing and EDA first.")

if __name__ == "__main__":
    main()
