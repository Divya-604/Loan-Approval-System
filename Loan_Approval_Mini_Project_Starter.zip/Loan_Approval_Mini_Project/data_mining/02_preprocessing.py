"""
Stage 2 placeholder.
We will implement missing-value handling, duplicate removal, outlier treatment,
encoding, scaling, and feature selection after inspecting the downloaded dataset.
"""
def main():
    print("Preprocessing stage is not configured yet.")
    print("First run: python data_mining\\01_inspect_data.py")
    print("Then share the output so preprocessing matches the real dataset columns.")

if __name__ == "__main__":
    main()
