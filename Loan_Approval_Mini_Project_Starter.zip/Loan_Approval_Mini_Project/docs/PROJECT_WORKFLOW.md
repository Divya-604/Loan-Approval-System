# Project workflow checklist

- [ ] Download public Kaggle dataset and place it at `dataset/train.csv`
- [ ] Inspect records, columns, data types, missing values, and duplicates
- [ ] Implement and verify preprocessing
- [ ] Create and save EDA visualizations in `outputs/`
- [ ] Train and evaluate model using a train/test split
- [ ] Save the fitted preprocessing/model pipeline in `artifacts/`
- [ ] Create Django project and dashboard app
- [ ] Implement CSV/XLSX upload and validation
- [ ] Display dataset summary and preview
- [ ] Generate visual analytics
- [ ] Display evaluation metrics and confusion matrix
- [ ] Implement prediction form
- [ ] Test normal and invalid uploads and prediction inputs
