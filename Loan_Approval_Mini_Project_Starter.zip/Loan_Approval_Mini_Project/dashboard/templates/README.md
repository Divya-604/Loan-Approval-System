HTML templates for upload, dashboard, and prediction pages will be added in the Django phase.
