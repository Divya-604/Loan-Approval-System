CSS and JavaScript assets for the dashboard will be added in the Django phase.
