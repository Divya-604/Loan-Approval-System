Django app code will be created here after the machine-learning pipeline is tested. We will generate the Django project and app with Django commands rather than manually inventing generated files.
