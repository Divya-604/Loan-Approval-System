Place the downloaded Kaggle training CSV here and name it `train.csv`.
Do not commit dataset files to GitHub unless the dataset license permits it.
